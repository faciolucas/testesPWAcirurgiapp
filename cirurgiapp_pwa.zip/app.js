if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(() => console.log('Service Worker registrado'));
}
document.querySelector('form').addEventListener('submit', e => {
    e.preventDefault();
    alert('Cirurgia registrada (simulação).');
});
